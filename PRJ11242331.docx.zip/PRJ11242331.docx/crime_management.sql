CREATE DATABASE IF NOT EXISTS crime_db;
USE crime_db;

CREATE TABLE Police_Station(
    station_id INT PRIMARY KEY,
    station_name VARCHAR(50),
    location VARCHAR(50)
);

CREATE TABLE Criminal(
    criminal_id INT PRIMARY KEY,
    name VARCHAR(50),
    age INT,
    gender VARCHAR(10),
    crime_type VARCHAR(50)
);

CREATE TABLE Victim(
    victim_id INT PRIMARY KEY,
    name VARCHAR(50),
    age INT,
    gender VARCHAR(10)
);

CREATE TABLE FIR(
fir_id INT PRIMARY KEY,
date DATE,
station_id INT,
victim_id INT,
FOREIGN KEY(station_id) REFERENCES Police_Station(station_id),
FOREIGN KEY(victim_id) REFERENCES Victim(victim_id)
);

CREATE TABLE Case_Details(
case_id INT PRIMARY KEY,
fir_id INT,
criminal_id INT,
status VARCHAR(20),
FOREIGN KEY(fir_id) REFERENCES FIR(fir_id),
FOREIGN KEY(criminal_id) REFERENCES Criminal(criminal_id)
);

INSERT INTO Police_Station VALUES
(1,'City Police Station','Delhi'),
(2,'Sector 10 Police Station','Chandigarh');

INSERT INTO Criminal VALUES
(101,'Rahul',25,'Male','Theft'),
(102,'Aman',30,'Male','Fraud');

INSERT INTO Victim VALUES
(201,'Riya',22,'Female'),
(202,'Karan',28,'Male');

INSERT INTO FIR VALUES
(1,'2024-01-10',1,201),
(2,'2024-02-15',2,202);

INSERT INTO Case_Details VALUES
(1,1,101,'Solved'),
(2,2,102,'Pending');

SELECT * FROM Criminal;
SELECT * FROM Victim;
SELECT * FROM Police_Station;

SELECT Criminal.name, Case_Details.status
FROM Criminal
JOIN Case_Details
ON Criminal.criminal_id = Case_Details.criminal_id;


